using SteamDatabase.ValvePak;

namespace GUI.Types.ParticleRenderer
{
    public class VrfGuiContext
    {
        public string FileName { get; set; }

        public Package CurrentPackage { get; set; }
    }
}
