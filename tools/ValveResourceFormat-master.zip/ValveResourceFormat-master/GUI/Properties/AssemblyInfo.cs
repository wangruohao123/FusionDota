﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Source 2 Resource Viewer")]
[assembly: AssemblyProduct("Source 2 Resource Viewer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Steam Database")]
[assembly: AssemblyCopyright("Steam Database")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.*")]
[assembly: ComVisible(false)]
[assembly: Guid("39c336bb-2add-4ab5-a3f0-e4e5e1aca6a5")]
