namespace GUI.Forms
{
    public enum SearchType
    {
        FileNameExactMatch,
        FileNamePartialMatch,
        FullPath,
        Regex,
    }
}
