﻿using System.Windows.Forms;

namespace GUI.Forms
{
    public partial class LoadingFile : UserControl
    {
        public LoadingFile()
        {
            InitializeComponent();
        }
    }
}
