using System;

namespace ValveResourceFormat
{
    public enum VTexExtraData
    {
#pragma warning disable 1591
        UNKNOWN = 0,
        FALLBACK_BITS = 1,
        SHEET = 2,
        FILL_TO_POWER_OF_TWO = 3,
        COMPRESSED_MIP_SIZE = 4,
#pragma warning restore 1591
    }
}
