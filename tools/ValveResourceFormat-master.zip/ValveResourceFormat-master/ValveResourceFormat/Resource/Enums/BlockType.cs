using System;

namespace ValveResourceFormat
{
    public enum BlockType
    {
#pragma warning disable 1591
        RERL = 1,
        REDI,
        NTRO,
        DATA,
        VBIB,
        VXVS,
        SNAP,
#pragma warning restore 1591
    }
}
