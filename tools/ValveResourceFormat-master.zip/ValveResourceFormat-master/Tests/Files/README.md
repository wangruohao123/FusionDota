These files were extracted from Dota 2 VPKs for testing purposes only.
